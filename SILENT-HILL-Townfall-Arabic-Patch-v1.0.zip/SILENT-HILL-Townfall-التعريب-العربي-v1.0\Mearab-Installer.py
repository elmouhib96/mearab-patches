# -*- coding: utf-8 -*-
"""المعراب — مثبت رسومي عام لتعريب واحد (tkinter، بدون اعتماديات خارجية).
يقرأ info.json و cover.png بجانبه. يعمل كـ EXE (PyInstaller) أو سكريبت.
اختبار صامت: gui_installer.py --install <game_path> | --uninstall [game_path]
"""
import json, os, shutil, sys, threading
from pathlib import Path

if getattr(sys, "frozen", False):
    HERE = Path(sys.executable).resolve().parent
else:
    HERE = Path(__file__).resolve().parent

try:
    INFO = json.loads((HERE / "info.json").read_text(encoding="utf-8"))
except Exception as e:
    INFO = {}
GAME_ID = INFO.get("id", "patch_ar")
GAME_NAME = INFO.get("name", "التعريب العربي")
GAME_VER = str(INFO.get("version", "1.0"))
DETECT_EXE = INFO.get("detect_exe", "")
DETECT_EXES = INFO.get("detect_exes", []) or ([DETECT_EXE] if DETECT_EXE else [])
DETECT_FILES = INFO.get("detect_files", []) or []
NEEDS_BEPINEX = str(INFO.get("bepinex", "v5")).lower() != "none"

APPDATA = Path(os.environ.get("APPDATA", str(Path.home()))) / "TaaribatAlmohib"
BACKUPS = APPDATA / "backups"

GOLD = "#e8c15a"; BG = "#07090f"; CARD = "#10141d"; TXT = "#f2ead6"; MUT = "#9aa3b2"

# ---------------- منطق التثبيت (مشترك GUI/CLI) ----------------
def _check(d: Path):
    try:
        for e in DETECT_EXES:
            if e and (d / e).exists():
                return True
        if DETECT_FILES and all((d / f).exists() for f in DETECT_FILES):
            return True
    except Exception:
        pass
    return False

def find_candidates():
    out, seen = [], set()
    def add(p: Path):
        s = str(p)
        if p.is_dir() and s not in seen:
            seen.add(s); out.append(p)
    for base in [Path("C:/Program Files (x86)/Steam/steamapps/common"),
                 Path("C:/Program Files/Steam/steamapps/common"),
                 Path("D:/Steam/steamapps/common")]:
        try:
            if base.is_dir():
                for c in base.iterdir():
                    if c.is_dir() and _check(c):
                        add(c)
        except Exception:
            pass
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
            sp, _ = winreg.QueryValueEx(k, "SteamPath")
            common = Path(sp) / "steamapps" / "common"
            if common.is_dir():
                for c in common.iterdir():
                    if c.is_dir() and _check(c):
                        add(c)
    except Exception:
        pass
    for root in [Path("D:/Games"), Path("E:/Games"), Path.home() / "Games"]:
        try:
            if not root.is_dir():
                continue
            for c in root.iterdir():
                if c.is_dir() and _check(c):
                    add(c)
        except Exception:
            pass
    return out

def is_bepinex_installed(g: Path) -> bool:
    try:
        if not (g / "winhttp.dll").exists():
            return False
        core = g / "BepInEx" / "core"
        return (core / "BepInEx.dll").exists() or (core / "BepInEx.Core.dll").exists()
    except Exception:
        return False

def do_install(game_path: str, log=print):
    g = Path(game_path)
    src_files = HERE / "files"
    if not g.is_dir():
        raise FileNotFoundError("مجلد اللعبة غير موجود: " + game_path)
    if not src_files.is_dir():
        raise FileNotFoundError("مجلد files/ غير موجود بجانب المثبت")
    log("📁 مجلد اللعبة: " + str(g))
    if NEEDS_BEPINEX:
        if is_bepinex_installed(g):
            log("✅ BepInEx موجود مسبقاً — تخطي.")
        else:
            src_bep = HERE / "runtime-bepinex"
            if not src_bep.is_dir():
                log("⚠️ مجلد runtime-bepinex/ ناقص — إكمال بدون BepInEx.")
            else:
                log("📦 تثبيت BepInEx المدمج...")
                for name in ("winhttp.dll", "doorstop_config.ini", "changelog.txt"):
                    s = src_bep / name
                    if s.exists():
                        shutil.copy2(s, g / name)
                (g / "BepInEx").mkdir(parents=True, exist_ok=True)
                bep = src_bep / "BepInEx"
                if bep.is_dir():
                    for item in bep.iterdir():
                        dst = g / "BepInEx" / item.name
                        try:
                            if item.is_dir():
                                if item.name == "plugins":
                                    dst.mkdir(parents=True, exist_ok=True)
                                elif not dst.exists():
                                    shutil.copytree(item, dst)
                            elif not dst.exists():
                                shutil.copy2(item, dst)
                        except Exception as e:
                            log(f"  ⚠️ {item.name}: {e}")
                log("✅ تم تثبيت BepInEx.")
    files = [p for p in src_files.rglob("*") if p.is_file()]
    b_root = BACKUPS / GAME_ID; b_files = b_root / "originals"
    b_root.mkdir(parents=True, exist_ok=True); b_files.mkdir(parents=True, exist_ok=True)
    backed, added = [], []
    for i, f in enumerate(files):
        rel = f.relative_to(src_files)
        t = g / rel
        t.parent.mkdir(parents=True, exist_ok=True)
        if t.exists():
            b = b_files / rel
            if not b.exists():
                b.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(t, b)
                backed.append(str(rel))
        else:
            added.append(str(rel))
        shutil.copy2(f, t)
    manifest = {"game_id": GAME_ID, "version": GAME_VER, "game_path": str(g),
                "backed_up": backed, "added": added}
    (b_root / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (g / ".taaribat_almohib.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    log(f"✅ تم تثبيت التعريب: {len(files)} ملفاً ({len(backed)} باكاب، {len(added)} جديد).")
    log("🎮 شغل اللعبة واستمتع بالعربية! قيّمنا ⭐ على الموقع.")
    return manifest

def do_uninstall(game_path: str | None, log=print):
    mp = BACKUPS / GAME_ID / "manifest.json"
    if game_path is None:
        if not mp.exists():
            raise FileNotFoundError("لا يوجد تثبيت مسجل لهذا التعريب.")
        game_path = json.loads(mp.read_text(encoding="utf-8")).get("game_path")
    manifest = json.loads(mp.read_text(encoding="utf-8")) if mp.exists() else {"added": [], "backed_up": []}
    g = Path(game_path)
    n1 = n2 = 0
    for rel in manifest.get("added", []):
        try:
            t = g / rel
            if t.exists():
                t.unlink(); n1 += 1
        except Exception:
            pass
    for rel in manifest.get("backed_up", []):
        try:
            b = BACKUPS / GAME_ID / "originals" / rel
            if b.exists():
                (g / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(b, g / rel); n2 += 1
        except Exception:
            pass
    try:
        (g / ".taaribat_almohib.json").unlink(missing_ok=True)
    except Exception:
        pass
    try:
        if mp.exists():
            mp.unlink()
    except Exception:
        pass
    log(f"🗑️ تم إلغاء التثبيت: حُذف {n1} ملفاً وأُعيد {n2} ملفاً أصلياً.")
    return True

# ---------------- وضع CLI (للاختبار) ----------------
if "--install" in sys.argv or "--uninstall" in sys.argv:
    try:
        import io as _io
        sys.stdout = _io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    except Exception:
        pass
    def _cli_log(m):
        try:
            print(m)
        except Exception:
            pass
    try:
        if "--install" in sys.argv:
            gp = sys.argv[sys.argv.index("--install") + 1]
            do_install(gp, _cli_log)
        else:
            i = sys.argv.index("--uninstall")
            gp = sys.argv[i + 1] if len(sys.argv) > i + 1 and not sys.argv[i + 1].startswith("-") else None
            do_uninstall(gp, _cli_log)
        _cli_log("CLI-OK")
    except Exception as e:
        _cli_log("CLI-FAIL: " + str(e)); sys.exit(1)
    sys.exit(0)

# ---------------- الواجهة ----------------
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

root = tk.Tk()
root.title(f"المعراب — تثبيت {GAME_NAME}")
root.geometry("560x720"); root.resizable(False, False)
root.configure(bg=BG)
try:
    ico = HERE / "icon.ico"
    if ico.exists():
        root.iconbitmap(str(ico))
except Exception:
    pass

style = ttk.Style(root)
try:
    style.theme_use("clam")
except Exception:
    pass
style.configure("Gold.Horizontal.TProgressbar", background=GOLD, troughcolor=CARD, borderwidth=0)

head = tk.Frame(root, bg=BG); head.pack(fill="x", padx=16, pady=(14, 4))
tk.Label(head, text="🌙 المعراب", font=("Segoe UI", 13, "bold"), bg=BG, fg=GOLD).pack(anchor="e")

cover_img = None
try:
    cp = HERE / "cover.png"
    if cp.exists():
        from tkinter import PhotoImage
        img = PhotoImage(file=str(cp))
        w, h = img.width(), img.height()
        if w > 500:
            k = max(1, w // 500)
            img = img.subsample(k, k)
        cover_img = img
        tk.Label(root, image=cover_img, bg=BG).pack(pady=4)
except Exception:
    pass

tk.Label(root, text=GAME_NAME, font=("Segoe UI", 15, "bold"), bg=BG, fg=TXT, wraplength=500, justify="right").pack(pady=(4, 0))
tk.Label(root, text=f"التعريب العربي • v{GAME_VER}", font=("Segoe UI", 10), bg=BG, fg=MUT).pack()

pf = tk.Frame(root, bg=BG); pf.pack(fill="x", padx=16, pady=10)
tk.Label(pf, text="مجلد اللعبة:", font=("Segoe UI", 10, "bold"), bg=BG, fg=TXT).pack(anchor="e")
er = tk.Frame(pf, bg=BG); er.pack(fill="x", pady=4)
path_var = tk.StringVar()
pe = tk.Entry(er, textvariable=path_var, font=("Segoe UI", 10), justify="right", bg=CARD, fg=TXT, insertbackground=TXT)
pe.pack(side="right", fill="x", expand=True)

def browse():
    sel = filedialog.askdirectory(title=f"اختر مجلد اللعبة — {GAME_NAME}")
    if sel:
        path_var.set(sel)

def auto():
    cands = find_candidates()
    if not cands:
        messagebox.showinfo("بحث تلقائي", "لم أعثر على اللعبة تلقائياً — اختر المجلد يدوياً.")
        return
    if len(cands) == 1:
        path_var.set(str(cands[0])); log("🔍 عُثر تلقائياً على: " + str(cands[0])); return
    win = tk.Toplevel(root); win.title("اختر مجلد اللعبة"); win.configure(bg=BG)
    tk.Label(win, text="وجدت عدة مجلدات — اختر الصحيح:", bg=BG, fg=TXT).pack(padx=12, pady=8)
    lb = tk.Listbox(win, width=70, bg=CARD, fg=TXT)
    for c in cands[:10]:
        lb.insert("end", str(c))
    lb.pack(padx=12, pady=4)
    def pick():
        try:
            path_var.set(lb.get(lb.curselection())); log("🔍 اخترت: " + path_var.get())
        except Exception:
            pass
        win.destroy()
    tk.Button(win, text="اختيار", command=pick, bg=GOLD, fg=BG, font=("Segoe UI", 10, "bold")).pack(pady=8)

tk.Button(er, text="📁 استعراض", command=browse, bg=CARD, fg=TXT).pack(side="left", padx=(6, 0))
tk.Button(er, text="🔍 بحث تلقائي", command=auto, bg=CARD, fg=GOLD).pack(side="left")

bf = tk.Frame(root, bg=BG); bf.pack(fill="x", padx=16, pady=4)
btn_install = tk.Button(bf, text="⬇ تثبيت شامل", font=("Segoe UI", 12, "bold"), bg=GOLD, fg=BG, height=2)
btn_uninst = tk.Button(bf, text="🗑 إلغاء التثبيت", font=("Segoe UI", 11), bg=CARD, fg=TXT, height=2)
btn_install.pack(side="right", fill="x", expand=True, padx=(0, 6))
btn_uninst.pack(side="left", fill="x", expand=True)

prog = ttk.Progressbar(root, style="Gold.Horizontal.TProgressbar", mode="indeterminate")
prog.pack(fill="x", padx=16, pady=8)
logbox = tk.Text(root, height=10, font=("Segoe UI", 9), bg=CARD, fg=TXT, wrap="word")
logbox.pack(fill="both", expand=True, padx=16, pady=(0, 12))

def log(msg):
    try:
        logbox.insert("end", msg + "\n"); logbox.see("end"); root.update_idletasks()
    except Exception:
        pass

def busy(on):
    for b in (btn_install, btn_uninst):
        try:
            b.config(state="disabled" if on else "normal")
        except Exception:
            pass
    try:
        prog.start(12) if on else prog.stop()
    except Exception:
        pass

def run_install():
    gp = path_var.get().strip().strip('"')
    if not gp or not Path(gp).is_dir():
        messagebox.showwarning("مجلد اللعبة", "اختر مجلد اللعبة أولاً (الذي يحتوي على ملف التشغيل).")
        return
    if DETECT_EXES and not any((Path(gp) / e).exists() for e in DETECT_EXES if e):
        if not messagebox.askyesno("تأكيد", f"لم أجد {DETECT_EXE} في هذا المجلد.\nمتابعة رغم ذلك؟"):
            return
    busy(True); log("⏳ بدأ التثبيت...")
    def job():
        try:
            do_install(gp, log)
            messagebox.showinfo("تم", "✅ تم تثبيت التعريب بنجاح!\nشغل اللعبة واستمتع بالعربية 🌙")
        except Exception as e:
            log("❌ " + str(e))
            messagebox.showerror("خطأ", str(e))
        busy(False)
    threading.Thread(target=job, daemon=True).start()

def run_uninstall():
    gp = path_var.get().strip().strip('"') or None
    if not messagebox.askyesno("تأكيد", "إلغاء تثبيت التعريب واسترجاع الملفات الأصلية؟"):
        return
    busy(True)
    def job():
        try:
            do_uninstall(gp, log)
            messagebox.showinfo("تم", "🗑️ تم إلغاء التثبيت واسترجاع الأصلية.")
        except Exception as e:
            log("❌ " + str(e))
            messagebox.showerror("خطأ", str(e))
        busy(False)
    threading.Thread(target=job, daemon=True).start()

btn_install.config(command=run_install)
btn_uninst.config(command=run_uninstall)
log(f"🌙 مرحباً بك في مثبت {GAME_NAME} — اختر مجلد اللعبة ثم اضغط «تثبيت شامل».")
root.mainloop()
